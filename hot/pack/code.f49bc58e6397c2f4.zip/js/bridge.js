/* ===================== js/bridge.js · 老 APK 的三科桥接加载器 =====================
 * 这个文件只活在 2.4.x 及更早的 App 上 —— 那批 App 的 boot.js 里没有"学科"这回事，
 * 清单写死是 js/app.js 这种根级路径，而 boot.js 又是热更覆盖不到的冻结文件。
 *
 * 【它凭什么能工作 —— 两条口子】
 *   ① 老 boot.js 会无条件追加注入资源包里任何符合 /^js\/.+\.js$/ 的新文件：
 *        if (BUILTIN.indexOf(p) < 0 && /^js\/.+\.js$/.test(p)) out.push(...)
 *      本文件就是走这条路进来的，排在所有内置脚本之后。
 *   ② 原生虚拟域 https://local.hot/ 是按路径直读 files/hot/ 下的任意文件，不挑清单：
 *        File f = new File(getFilesDir(), "hot/" + path);
 *      所以我自己创建的 <script> / <link> 标签同样取得到三科子目录里的东西。
 *
 * 两条合起来等于：**不出新 APK，也能让老 App 换一套加载行为。**
 * 改 boot.js 那条路是不许走的（手册 §0 铁律）—— 这次走的是这儿。
 *
 * 【★ 2026-09-20 现场事故：老机上选学科页是"闪一下就没了"】
 *   现象：进去能看到语文/数学/英语三张卡，三五秒后自动跳进语文。
 *   根因：老 boot.js 的内置清单里**第一个**是 js/app.js，语文那一整套会先跑完
 *         （它自己有"没选学科就默认语文"的逻辑），渲染出语文首页；
 *         之后本文件才被注入，才轮到选学科页 —— 于是选学科页只是"覆盖"了一下，
 *         而语文那边还在跑（自动进入、定时器、二次渲染都会把它翻回来）。
 *   解法：**让语文那套根本不执行**。资源包把 js/app.js 换成的不是空壳，
 *         而是一个"先判断有没有选过学科、没选就直接渲染选学科页并 return"的小文件
 *         （见 legacy/js/app.js）。它排在第一位，于是页面上从来就没有语文跑起来过，
 *         用户选完学科 reload 之后它才放行真正的学科文件。
 *   附带好处：无论用户怎么退出重进，只要没选学科就一定会停在选择页 ——
 *         这正是用户最初的要求（"进去能发现语文数学英语选项，不要自己跳走"）。
 *
 * 【配套还必须有三个空壳】
 *   老的 boot.js 一定会先把语文那一整套注进来。资源包里同时顶掉了
 *   js/app.js / js/games.js / js/game-battle.js / js/update.js 这四个根级路径：
 *     · js/app.js    → 不再是空壳，是"选学科看门人"（见上）
 *     · js/games.js / js/game-battle.js / js/update.js → 纯空壳
 *   真正干活的是本文件动态加载的那一份学科文件。
 *   不然同一份 app.js 被执行两遍，连点击监听器都会挂两份 —— 按一下走两步。
 * ============================================================================== */
(function () {
  "use strict";

  /* 新版宿主（2.5.0+）自带三科支持；本文件万一出现在那儿，立刻退场，不能两套机制并存 */
  if (window.APP_SUBJECTS) return;
  if (window.__bridgeLoaded) return;
  window.__bridgeLoaded = true;

  var KEY = "app_subject";        /* 与新版 boot.js 用同一个 localStorage 键，将来换包也不用重新选 */
  var LAST = "app_subject_last";
  var HOT = "https://local.hot/";

  /* 三科清单 —— 顺序即加载顺序，必须和 boot.js 里各科的 BUILTIN 保持一致。
     ★ tv.js / tv-tune.js 不在这里：它们由老 boot.js 的内置清单加载，
       而且资源包用同路径覆盖成了新版共享层，加载器不用操心。
     ★ 顺序里的硬约束：app.js 必须排在 tv.js 之前（tv 要包装 render），
       所以这里加载完学科文件后还要再调一次 __tvRearmRender() 补包装。 */
  var SUBJECTS = {
    cn: {
      key: "cn", dir: "cn", css: "cn/css/style.css", label: "语文", emoji: "📖",
      files: [
        "cn/js/cp.js",
        "cn/js/data-c1.js", "cn/js/data-c2.js", "cn/js/data-c3.js",
        "cn/js/data-c4.js", "cn/js/data-c5.js", "cn/js/data-c6.js",
        "cn/js/strokes.js",
        "cn/js/data-poem.js",
        "cn/js/data-word.js",
        "cn/js/tts.js",
        "cn/js/praise.js",
        "cn/js/pics.js",
        "cn/js/games.js",
        "cn/js/game-battle.js",
        "cn/js/app.js",
        "cn/js/update.js"
      ]
    },
    math: {
      key: "math", dir: "math", css: "math/css/style.css", label: "数学", emoji: "🔢",
      files: [
        "math/js/cp.js",
        "math/js/data-m1.js", "math/js/data-m2.js", "math/js/data-m3.js",
        "math/js/data-m4.js", "math/js/data-m5.js", "math/js/data-m6.js",
        "math/js/data-extra.js",
        "math/js/gen.js",
        "math/js/tts.js",
        "math/js/praise.js",
        "math/js/games.js",
        "math/js/game-battle.js",
        "math/js/app.js",
        "math/js/update.js"
      ]
    },
    en: {
      key: "en", dir: "en", css: "en/css/style.css", label: "英语", emoji: "🔤",
      files: [
        "en/js/cp.js",
        "en/js/data-g1.js", "en/js/data-g2.js", "en/js/data-g3.js",
        "en/js/data-g4.js", "en/js/data-g5.js", "en/js/data-g6.js",
        "en/js/tts.js",
        "en/js/praise.js",
        "en/js/games.js",
        "en/js/game-battle.js",
        "en/js/app.js",
        "en/js/update.js"
      ]
    }
  };

  function log(s) { try { console.log("[bridge] " + s); } catch (e) {} }
  function get(k) { try { return localStorage.getItem(k) || ""; } catch (e) { return ""; } }
  function set(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }

  /* ---------- 顺序加载：必须串行 ----------
     并发 <script> 会打乱执行顺序；而各科的 data-*.js 只是定义常量、
     app.js 却要在最后才用到它们 —— 顺序一乱就是大面积 undefined。
     ★ 单个文件失败要放过：资源包可能是旧 build 缺了新文件，
       整链中断会让 App 停在白屏，还不如带着缺的那一个继续跑。 */
  function loadSeq(files, done) {
    var i = 0;
    (function next() {
      if (i >= files.length) { done(); return; }
      var p = files[i++];
      var s = document.createElement("script");
      s.src = HOT + p;
      s.async = false;
      s.onload = function () { next(); };
      s.onerror = function () {
        log("跳过缺失文件 " + p);
        if (s.parentNode) s.parentNode.removeChild(s);
        next();
      };
      document.head.appendChild(s);
    })();
  }

  /* ---------- 从已装资源包的清单里补上「新增玩法」 ----------
     ★ 2026-09-21 事故复盘：这份静态清单漏了 math / en 的 game-battle.js，
       于是老机上英语、数学的知识圈**永远不上线**（语文正常，纯粹因为
       cn/js/game-battle.js 是 APK 内置的、不靠热更注入）。
       静态清单是人手维护的，迟早还会再漏一次 —— 所以这里改成：
       从已装资源包的 MANIFEST 里，把本学科目录下的玩法文件
       （名字形如 game-xxx.js）自动补进来，位置仍在学科 games.js 之后
       （registerGame 必须先存在，否则玩法文件会安全降级不注册）。
       桥或清单取不到时静默退回静态清单，行为与以前完全一致。 */
  function withPackGames(files, dir) {
    try {
      var H = window.AndroidHot;
      if (!H || typeof H.manifest !== "function") return files;
      var t = H.manifest();
      if (!t) return files;
      var m = JSON.parse(t);
      if (!m || !m.files || !m.files.length) return files;
      var extra = [], i, p;
      for (i = 0; i < m.files.length; i++) {
        p = m.files[i] && m.files[i].p;
        if (typeof p !== "string" || p.indexOf(dir + "/js/") !== 0) continue;
        if (!/\.js$/.test(p)) continue;
        if (files.indexOf(p) >= 0) continue;
        if (!/\/game-[^\/]+\.js$/.test(p)) continue;   /* 只补玩法文件，别的没登记不乱注 */
        extra.push(p);
      }
      if (!extra.length) return files;
      var out = files.slice(), at = -1;
      for (i = 0; i < out.length; i++) if (/js\/games\.js$/.test(out[i])) at = i;
      if (at < 0) at = out.length - 1;
      for (i = 0; i < extra.length; i++) out.splice(at + 1 + i, 0, extra[i]);
      log("补入资源包玩法：" + extra.join("、"));
      return out;
    } catch (e) { return files; }
  }

  /* ---------- 样式：shell → 学科 → tv ----------
     老 index.html 只有 #css0（语文 style.css）和 #cssTV。
     #css0 必须撤掉：留着它，数学/英语的界面会被语文的配色和布局规则污染。 */
  function mountCss(subjCss) {
    var anchor = document.getElementById("cssTV");
    var old0 = document.getElementById("css0");
    if (old0 && old0.parentNode) old0.parentNode.removeChild(old0);

    function add(id, href) {
      if (document.getElementById(id)) return;
      var l = document.createElement("link");
      l.rel = "stylesheet"; l.id = id; l.href = href;
      if (anchor && anchor.parentNode) anchor.parentNode.insertBefore(l, anchor);
      else document.head.appendChild(l);
    }
    add("cssShell", HOT + "css/shell.css");
    if (subjCss) add("cssSub", HOT + subjCss);
    /* 首页那条学科切换栏的样式在 picker.css 里 —— 学科页也必须把它带上，
       不然条会掉成浏览器默认样式（手机上还行，电视上按钮小到看不见）。 */
    add("cssPick", HOT + "css/picker.css");
  }

  /* ---------- 换学科入口 ----------
     老版 index.html 的设置面板里没有「🔄 换学科」这一行，跑到这里补上。
     同时挂到 window.__pickSubject —— 各科代码里约定俗成的就是这个名字。
     ★ 幂等：看门人（legacy/js/app.js）也会挂同一个函数，先到先得，不要互相覆盖
       （两者语义一致：清掉 app_subject + reload）。 */
  if (typeof window.__pickSubject !== "function") {
    window.__pickSubject = function () {
      set(KEY, "");
      try { location.reload(); } catch (e) {}
    };
  }
  /* ---------- 换学科入口：首页顶部一条，不放设置里 ----------
     用户原话：「选学科不要放设置，最好放首页显眼处」。
     老 index.html 的结构是 <div id="app"> 在最前，所以把条插在 #app **之前**。
     为什么不插进 #app 里：学科 App 的 render 会重建 #app 的内容，条会被冲掉，
     插在外面就不用每帧跟它抢位置。
     ★ 电视上必须能被遥控器聚焦到 —— 用真 <button>，配大点击区与焦点环
       （样式在 css/picker.css 的 #subjectBar 段）。 */
  function mountSubjectBar(key) {
    if (document.getElementById("subjectBar")) return null;
    var s = SUBJECTS[key];
    var bar = document.createElement("div");
    bar.id = "subjectBar";
    bar.setAttribute("data-subject-bar", "1");
    bar.innerHTML =
      '<span class="sb-cur">' + (s ? s.emoji + " " : "📚 ") +
      '当前学科：<b>' + (s ? s.label : "未选择") + '</b></span>' +
      '<button class="sb-btn" type="button" ' +
      'onclick="window.__pickSubject&&window.__pickSubject()">🔄 换学科</button>';
    var app = document.getElementById("app");
    if (app && app.parentNode) app.parentNode.insertBefore(bar, app);
    else document.body.insertBefore(bar, document.body.firstChild);
    log("首页学科条已挂载：" + (s ? s.label : "未选择"));
    return bar;
  }

  /* 兜底：万一有别的代码把整层 body 重建了，重挂一次。
     幂等 —— #subjectBar 已存在时 mountSubjectBar 直接返回 null。 */
  setTimeout(function () { mountSubjectBar(get(KEY)); }, 1200);
  setTimeout(function () { mountSubjectBar(get(KEY)); }, 3000);

  /* ---------- 走分区 ----------
     ★ 选学科页复用新版那份 js/subject.js（同一个文件、同一套文案与遥控器逻辑），
       这里只需要给它补上一个 __setSubject —— 老 App 里没有这个全局函数。 */
  window.__setSubject = function (k) {
    if (!SUBJECTS[k]) { log("未知学科 " + k); return; }
    set(KEY, k); set(LAST, k);
    try { location.reload(); } catch (e) {}
  };

  var cur = get(KEY);

  if (!cur || !SUBJECTS[cur]) {
    /* ===== 还没选：必须停在选学科页 ===== */
    if (cur) set(KEY, "");          // 脏数据：写错学科名时别卡死在选择页
    mountCss(null);
    window.APP_SUBJECT = "";
    log("未选学科 → 渲染选学科页（不加载任何学科）");

    /* subject.js 可能已经被老 boot.js 里的看门人（覆盖掉的 js/app.js）加载过了。
       这里直接调它的渲染函数，不再重复注入 —— 重复注入会 render() 两遍。 */
    function paintPicker() {
      if (typeof window.__renderSubjectPicker === "function") {
        try { window.__renderSubjectPicker(); log("选学科页就绪（复用已加载的 subject.js）"); return true; }
        catch (e) { log("renderSubjectPicker 失败 " + e); }
      }
      return false;
    }
    if (!paintPicker()) {
      loadSeq(["js/subject.js"], function () { paintPicker(); });
    }

    /* ★ 兜底重绘：万一有别的脚本把 #app 覆盖了（学科遗留的定时器 / 二次 render），
       把选学科页抢回来。只在"确实被覆盖"时才动手，不做无脑刷新。 */
    var guard = 0;
    var iv = setInterval(function () {
      guard++;
      var el = document.getElementById("app");
      var ok = !!(el && el.querySelector(".subj-grid"));
      if (!ok) { log("选学科页被覆盖，重绘第 " + guard + " 次"); paintPicker(); }
      if (guard >= 20) clearInterval(iv);       // 最多守 20 秒，之后交给用户
    }, 1000);
    return;
  }

  /* ===== 已选：按清单加载那一科 ===== */
  var subj = SUBJECTS[cur];
  window.APP_SUBJECT = cur;                 // 与新版宿主对齐，别让各科找不到上下文
  mountCss(subj.css);
  /* 学科条**立刻**挂，不等 18 个学科文件加载完 ——
     机顶盒上那一两秒里如果屏幕上什么都没有，用户会以为卡住了。 */
  mountSubjectBar(cur);
  loadSeq(withPackGames(subj.files, subj.dir), function () {
    /* 学科 App 是 tv.js 跑完之后才加载的 —— window.render 此刻才第一次出现，
       必须补一次包装，否则机顶盒上每次切页焦点都不会复位。
       这也是为什么一开始就要求 app.js 排在 tv.js 之前、然后由这里兜底。 */
    try { if (window.__tvRearmRender) window.__tvRearmRender(); } catch (e) {}
    mountSubjectBar(cur);
    /* App 自己可能已经渲染过一次（渲染完我还没包装），再渲染一次让焦点落到内容区 */
    try { if (typeof window.render === "function") window.render(); } catch (e) {}
    log("已加载学科 " + cur + "（" + subj.files.length + " 个文件）");
  });
})();
